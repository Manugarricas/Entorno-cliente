const Product = require("../models/product")
const { validationResult } = require('express-validator');
  const getProducts = async (req, res) => {
    try {
        const products = await Product.find();
        res.status(200).json(products);

    } catch (error) {
        res.status(500).json({ message: error })
    }

}

  const addProduct = async (req, res) => {
   
    const product = req.body;
    //Validaciones
    const newProduct = new Product(product);
    try {
      await newProduct.save();
      res.status(201).json(newProduct);
      
    } catch (error) {
      res.status(500).json({message: error})
    }
  }

  const delProduct = async (req, res) => {
   
    const product = req.params._id;
    try {
      const response = await Product.deleteMany({"_id":product});
      res.status(201).json(response);
      
    } catch (error) {
      res.status(500).json({message: error})
    }
  }

  const updateProduct = async (req, res) => {
   
    const product = req.params._id;
    const updateData = req.body;
    try {
      const response = await Product.updateOne({"_id":product}, updateData);
      res.status(201).json(response);
      
    } catch (error) {
      res.status(500).json({message: error})
    }
  }

module.exports = {getProducts, addProduct, delProduct, updateProduct};