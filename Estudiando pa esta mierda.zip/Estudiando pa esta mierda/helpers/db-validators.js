const Product = require('../models/product')

const existsProduct = async (nombre) => {
    const nameOb = await Product.findOne({nombre});
    if(nameOb){
        throw new Error(`El objeto ${nombre} already exists in database`);
    }
}

module.exports = {existsProduct};