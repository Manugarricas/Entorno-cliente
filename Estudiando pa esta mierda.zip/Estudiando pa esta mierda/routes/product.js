const express = require("express");
const router = express.Router();
const { check } = require('express-validator');
const { getProducts, addProduct, delProduct, updateProduct} = require('../controllers/product');
const { validateFields } = require("../middlewares/validate-fields");
const { existsProduct } = require("../helpers/db-validators");

router.route('/').get(getProducts).post([
    check('nombre').custom(existsProduct),
    check('nombre','Nombre is required champion').not().isEmpty(),
    check('precio', 'El precio debe ser un número').isInt({min:0}),
    check('stock', 'El stock no puede ser inferior a 0').isInt({min:0}),
    validateFields
],addProduct)

router
.route("/:_id")
.delete(delProduct);

router
.route("/:_id")
.put([
    check('nombre', 'El nombre no se puede actualizar').isEmpty(),
    validateFields
],updateProduct);

module.exports = router;