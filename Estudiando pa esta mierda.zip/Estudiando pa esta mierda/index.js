const express = require("express");
const cors = require('cors')
const app = express();
const productRoutes = require('./routes/product');
// const dotenv = require('dotenv')
// dotenv.config()
require('dotenv').config();

// Database conection

const mongoose = require("mongoose");
mongoose.set("strictQuery", false);

async function main() {
    await mongoose.connect(process.env.MONGO_CNN);
    console.log('Database connected'); 
}
main().catch((err) => console.log(err));


app.use(cors());
app.use(express.json())

// Ruta para obtener la lista de productos
app.use('/product', productRoutes);


// Iniciar el servidor en el puerto 3000
app.listen(process.env.PORT, () => {
  console.log(`Servidor en funcionamiento en el puerto ${process.env.PORT}`);
})
